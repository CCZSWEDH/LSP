file_log=/sdcard/Android/Apower
file=${0%/*}
file_path=$file/Variable.prop
battery_capacity=$(cat /sys/class/power_supply/battery/capacity)
battery_variable=$(grep 'battery=' $file/Variable.prop | cut -d'=' -f2)
if [ "$battery_capacity" = "$battery_variable" ]; then
    q=1
else
    sh $file/renew.sh
fi
w=$(grep 'state' "$file/Variable.prop" | awk -F'=' '{print $2}')
status=$(cat /sys/class/power_supply/battery/status)
sed -i "/state=/s/.*/state=$status/" $file_path
if [[ $battery_capacity -eq 100 && $status == "Charging" ]]; then
    sh $file/full.sh
    while true; do
    status=$(cat /sys/class/power_supply/battery/status)
    sed -i "/state=/s/.*/state=$status/" $file_path
        if [ "$status" == "Discharging" ]; then
        w=Discharging
        sh $file/finish_full.sh
            break
        fi
        sleep 5
    done
else
    q=1
fi
if [ "$status" = "$w" ]; then
    q=1
else
    if [ "$status" = "Charging" ]; then
        sh $file/start.sh
    else
        sh $file/finish.sh
    fi
fi
filename="$file_log/日志.txt"
if test -e $file/open ; then
if [ "$w" = "Charging" ]
then
    if [ -f "$filename" ] && [ $(wc -l < "$filename") -ge 51 ]; then
    sed -i '1d' "$filename"
    fi
else
    if [ -f "$filename" ] && [ $(wc -l < "$filename") -ge 16 ]; then
    sed -i '1d' "$filename"
    fi
fi
fi