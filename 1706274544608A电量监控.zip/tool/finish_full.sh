file=${0%/*}
file_log=/sdcard/Android/Apower/日志.txt
file_path=$file/Variable.prop
time_charge=$(grep 'ti_charge' "$file_path" | awk -F'=' '{print $2}')
time=$(date +"%Y-%m-%d %H:%M:%S")
timestamp_charge=$(date -d "$time_charge" +%s)
timestamp=$(date -d "$time" +%s)
diff=$(($timestamp - $timestamp_charge))
minutes=$((diff / 60))
seconds=$((diff % 60))
hours=$((minutes / 60))
minutes=$((minutes % 60))
diff_time="$hours时$minutes分$seconds秒"
frequency=$(grep 'frequency' "$file_path" | awk -F'=' '{print $2}')
frequency_new=$(($frequency + 1))
echo "充电器已断开，充满后$diff_time断开充电器，今日充电次数:$frequency_new" >> $file_log
sed -i "/ti_charge=/s/.*/ti_charge=$time/" $file_path
sed -i "/time=/s/.*/time=$time/" $file_path
sed -i "/frequency=/s/.*/frequency=$frequency_new/" $file_path