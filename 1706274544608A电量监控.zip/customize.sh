file_log=/sdcard/Android/Apower
mkdir $file_log
touch $file_log/自动清理日志状态:关
touch $file_log/日志.txt
echo 'file=/data/adb/modules/Apower/tool
time=$(cat $file/Variable.prop | grep ti_charge | cut -d = -f 2)
d=$(cat $file/Variable.prop | grep ti_charge | cut -d = -f 2)
time_stamp=$(date -d "$time" +%s)
current_time_stamp=$(date +%s)
time_diff=$((current_time_stamp - time_stamp))
hours=$((time_diff / 3600))
minutes=$((time_diff % 3600 / 60))
seconds=$((time_diff % 60))
battery=$(cat $file/Variable.prop | grep ba_charge | cut -d = -f 2)
battery_time=$(cat $file/Variable.prop | grep battery | cut -d = -f 2)
if [ "$battery_time" -gt "$battery" ]; then
  result=$((battery_time - battery))
  q="充了"
  a="充电器插入"
  b="充电时长"
else
  result=$((battery - battery_time))
  q="掉了"
  a="充电器断开"
  b="使用时长"
fi
echo "$a时间:$d
$a时电量:$battery%
$b:$hours时$minutes分$seconds秒
一共$q:$result%"' > $file_log/使用情况.sh
echo 'file=/data/adb/modules/Apower/tool
file_log=/storage/emulated/0/Android/Apower
rm $file_log/自动清理日志状态:关 &>/dev/null
rm $file_log/自动清理日志状态:开 &>/dev/null
if test -e $file/open ; then
rm $file/open
echo "关闭自动清理"
touch $file_log/自动清理日志状态:关
else
touch $file/open
echo "开启自动清理"
touch $file_log/自动清理日志状态:开
fi' > $file_log/开启_关闭自动清理日志.sh
echo 'file=/data/adb/modules/Apower/tool
reboot=$(cat $file/Variable.prop | grep reboot | cut -d = -f 2)
frequency=$(cat $file/Variable.prop | grep frequency | cut -d = -f 2)
echo "重启:$reboot次，充电:$frequency次"' > $file_log/查看重启充电次数.sh
cat << 'EOF' > $file_log/手动清理日志.sh
filename=/storage/emulated/0/Android/Apower/日志.txt
echo "稍微等待一会"
while true; do
    if [ -f "$filename" ] && [ $(wc -l < "$filename") -ge 6 ]; then
    sed -i '1d' "$filename"
else
    echo "清理完成，保留5条"
    exit 0
    fi
done
EOF
file_tool=/data/adb/modules/Apower/tool
set_perm_recursive $MODPATH/tool 0 0 0755 0755
echo "日志在$file_log
第一次更新日志100%不准确
等第二次更新就正常了
充电放电记录也是
使用时日志保留15条
充电保留50条
[开启_关闭自动清理日志.sh]可以打开或关闭
第一天的第一次重启(也就是模块刷入的这一次重启)日志内会有记录，但实际并未真正记录"